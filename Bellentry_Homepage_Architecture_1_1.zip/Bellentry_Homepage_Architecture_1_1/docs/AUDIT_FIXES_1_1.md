# Bellentry Homepage Architecture 1.1 — Audit Fixes

## Fixed from the 2026-10-04 deep audit
- Property Check validates complete radio groups; every goal and property type can advance.
- Fullscreen menu now traps focus, isolates main/footer with `inert`, supports Escape, and returns focus.
- Property inquiry context is preserved from `beratung.html?objekt=<slug>` and displayed in the form.
- Consultation now requires name, email, topic, message and consent in the standalone preview. It still does not fake a send.
- Search empty states are intent-aware: Buy and Temporary Living no longer look like broken filters or mislabel rental inventory.
- Gallery has active state and keyboard left/right navigation.
- Spatial Property Layer Phase 1 added to Groß Flottbek: interactive floorplan hotspots link room/access concepts to media and detail text.
- Meta description, canonical, Open Graph and Organization JSON-LD added to all generated pages (still `noindex` until launch).
- Responsive 640/960 WebP derivatives generated; HTML images receive intrinsic dimensions and `srcset` when variants exist.
- `robots.txt`, `sitemap.xml` and a 404 artifact added for deployment preparation.
- Production server now fails fast on the default session secret or SQLite and no longer runs `create_all()` in production.

## Deliberately not faked
- Buy inventory and short-stay inventory do not exist in the current source set, so none were invented.
- No live email/contact send is claimed in the standalone package.
- No photorealistic 3D/digital twin is fabricated from insufficient source material. Spatial Phase 1 uses the real floorplan/media relationship and prepares the data model direction.
- Full public pages are not yet all server-rendered from the persistent domain. That remains the major integration milestone rather than being hidden by a static facade.

## Remaining production gates
Authentication/RBAC, rate limiting, observability, upload quarantine/malware scanning, PostgreSQL staging, backup/restore, consent/retention policy, provider strategy for 360/3D, Safari/iOS and screen-reader QA.
