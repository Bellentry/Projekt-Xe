# Homepage Architecture 1.0

## Problem solved
The 0.5.2 opening over-indexed on cinematic explanation. A visitor was asked to decode Bellentry before being given the normal real-estate actions they came for. The new architecture reverses that order.

## Public sequence

### Orientation hero
Purpose: answer immediately: Where am I? What can I do? What is Bellentry?
Visible actions: Mieten, Kaufen, Wohnen auf Zeit, Ort, Objektart, Suche, Eigentümer entry.
No chapter numbers, design-process labels or internal system language.

### Two primary paths
`Ich suche` and `Ich besitze` establish the two dominant entry intents without exposing the entire product taxonomy at once.

### Selected real properties
The homepage proves that Bellentry is an actual real-estate product before explaining the system behind it. Every property has a dedicated page and save action.

### Cinematic Property Intelligence
The Archer-inspired choreography is retained but moved later. It explains one Bellentry-specific idea: a property moves from spatial impression to structured object and field-level evidence. It is not the navigation system of the homepage.

### Bellentry system
Property Passport, Bellentry Verified and My Bellentry are explained as user benefits, not internal architecture.

### Owner stage
Selling, letting, management and Property Check receive distinct entry points and distinct pages.

### Further journeys
Building/renovating, financing, investing and temporary living are not hidden, but they sit after the core real-estate actions.

### Trust / contact
The closing section explains the design principle in plain language and leads to consultation or knowledge content.

## Reference principle
Conventional premium real-estate sites demonstrate that search intent, property discovery and owner actions must be recognizable immediately. Bellentry retains those conventions where they reduce cognitive load, then differentiates through property intelligence, evidence, multi-role journeys and the connected system behind the pages.
