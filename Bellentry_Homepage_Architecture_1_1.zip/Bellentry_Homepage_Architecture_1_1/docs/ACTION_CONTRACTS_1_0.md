# Bellentry Action Contracts 1.0

Every visible primary control must have an observable outcome. Decorative affordances are prohibited.

| Surface | Action | Observable outcome | Preview implementation | QA |
|---|---|---|---|---|
| Header | Logo | Return to homepage | `index.html` | link target checked |
| Header | Immobilien / Mieten / Kaufen / Eigentum / Services | Open dedicated surface | separate HTML page | link target checked |
| Header | Mein Bellentry | Open personal workspace | `mein-bellentry.html` | link target checked |
| Header | Menu | Open/close full navigation | JS toggle + Escape | browser tested |
| Hero | Mieten / Kaufen / Wohnen auf Zeit | Set search intent | radio state | browser render checked |
| Hero | Immobilien suchen | Open search with GET query | relative form action | target/query contract checked |
| Hero | Eigentümer CTA | Open owner hub | `eigentum.html` | link target checked |
| Property card | Card/title | Open dedicated property page | relative page | link target checked |
| Property card | Merken | Toggle session-only save state | sessionStorage with `window.name` fallback; no PII | browser tested |
| Search | Filter | Recompute preview result set + URL state | client-side | browser tested |
| Search | Reset | Restore all preview results | client-side | browser tested |
| Property | Gallery thumbnail | Replace main image | client-side | browser tested |
| Property | Interesse anfragen | Open consultation in property context | relative link with query | link target checked |
| Property | Merken | Add/remove property from current-session workspace | client-side, no PII | browser tested |
| Passport | Zur Immobilie | Return to source property | relative link | link target checked |
| My Bellentry | Saved property | Open saved property | dynamic safe DOM creation | browser tested |
| My Bellentry | Entfernen | Remove from session list | dynamic safe DOM | browser tested |
| Property Check | Weiter / Zurück | Navigate actual multi-step state | client-side | browser tested |
| Property Check | Vorhaben besprechen | Open consultation | relative link | browser tested + target checked |
| Consultation | Anfrage vorbereiten | Validate fields and show transparent preview status | no send/no storage | browser tested |
| Footer | Product/service links | Open corresponding expanded pages | relative links | link target checked |

## Production distinction
The standalone consultation form does not pretend to submit. The preserved `server_core/` contains the existing real FastAPI inquiry transaction proof for Groß Flottbek. Production will replace the standalone completion state with the server action, CSRF, validation, journey creation and audit event.
