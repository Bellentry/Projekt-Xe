# Change Record 1.0

## KEEP
- Canonical Bellentry full logo and mobile mark.
- Cream / ink / restrained bronze identity.
- Property Passport and field-level truth concept.
- Groß-Flottbek Property Core proof and existing server-domain work.
- My Bellentry direction.
- Cinematic spatial-to-evidence concept.
- No fake production success states.

## CHANGE
- Cinematic sequence is no longer the homepage entry/navigation model.
- Homepage hero becomes immediate orientation + search.
- Public chapter counters and `01 / 02 / 03 / 04` labels are removed.
- Information architecture prioritizes real-estate intent before system explanation.

## ADD
- 20-page standalone public route set.
- Functional preview search/filtering.
- Functional save/My Bellentry session flow.
- Functional gallery controls.
- Functional multi-step Property Check.
- Expanded owner/service/knowledge surfaces.
- Action-contract and link-target QA.

## REMOVE
- Design-presentation style scene numbering from the public landing.
- Low-information hero behavior that required several viewport lengths before normal real-estate actions became clear.
