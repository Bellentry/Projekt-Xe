# Spatial Property Layer — Phase 1

The purpose is spatial understanding, not decorative 3D.

Current proof on Groß Flottbek:
- real floorplan as navigation surface;
- room/access hotspots;
- room selection synchronized to a related property image;
- explicit Access concept separated from the unit floorplan.

Target domain model:
`Building -> Entrance -> Level -> Unit -> Space`, plus `SpatialNode`, `SpatialEdge`, `TourScene`, `Hotspot`, `MediaAnchor`, `SpatialAsset`, and accessibility attributes.

Next spatial asset gate before 3D:
1. verify room polygons against a reliable floorplan/CAD source;
2. map each property photo to a room and camera direction;
3. capture building entrance/common-area/level/unit-door assets;
4. only then choose 360/provider-backed 3D or glTF/GLB/digital-twin production.

A 3D viewer must never be required to understand the property. 2D remains the fast, accessible fallback.
