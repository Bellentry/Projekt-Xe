# Route Manifest — Standalone Public Preview

- `index.html` — public homepage
- `immobilien.html` — search/results
- `mieten.html` — rental journey
- `kaufen.html` — purchase journey
- `wohnen-auf-zeit.html` — temporary-living journey
- `eigentum.html` — owner hub
- `vermieten.html` — letting journey
- `verkaufen.html` — sale journey
- `property-check.html` — interactive owner intake
- `verwaltung.html` — management journey
- `bauen-sanieren.html` — build/renovation journey
- `finanzieren.html` — financing journey
- `investieren.html` — investment journey
- `beratung.html` — consultation surface
- `wissen.html` — knowledge surface
- `mein-bellentry.html` — personal preview workspace
- `property-gross-flottbek.html` — dedicated property
- `property-rothenburgsort.html` — dedicated property
- `property-rissen-suurheid.html` — dedicated property
- `passport-gross-flottbek.html` — Property Passport / Verified example

All public routes are files in the standalone export and all current local href targets are checked by `qa/run_static_qa.py`.
