from sqlalchemy import select
from app.models import PropertyFact
from app.services.projections import load_property, public_projection, passport_projection

def test_same_fact_drives_public_and_passport(db):
    p=load_property(db,"BTY-HH-GF-000001")
    pub=public_projection(p); passport=passport_projection(p)
    assert next(x for x in pub["facts"] if x["key"]=="living_area_sqm")["value"] == "~51 m²"
    assert next(x for x in passport["facts"] if x["key"]=="living_area_sqm")["value"] == "~51 m²"
    fact=db.execute(select(PropertyFact).where(PropertyFact.fact_key=="living_area_sqm")).scalar_one()
    fact.display_value="52 m²"; db.commit(); db.expire_all()
    p=load_property(db,"BTY-HH-GF-000001")
    assert next(x for x in public_projection(p)["facts"] if x["key"]=="living_area_sqm")["value"] == "52 m²"
    assert next(x for x in passport_projection(p)["facts"] if x["key"]=="living_area_sqm")["value"] == "52 m²"

def test_conflict_preserves_both_values(db):
    p=passport_projection(load_property(db,"BTY-HH-GF-000001"))
    c=p["conflicts"][0]
    vals={f["value"] for f in c["facts"]}
    assert any("93,1" in v for v in vals) and any("118" in v for v in vals)
    assert c["state"]=="open"
