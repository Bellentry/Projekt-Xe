import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.db import Base
from app.seed import seed_db

@pytest.fixture
def db():
    engine=create_engine("sqlite+pysqlite:///:memory:",connect_args={"check_same_thread":False},future=True)
    Base.metadata.create_all(engine)
    Session=sessionmaker(bind=engine,expire_on_commit=False,future=True)
    s=Session(); seed_db(s)
    try: yield s
    finally: s.close()
