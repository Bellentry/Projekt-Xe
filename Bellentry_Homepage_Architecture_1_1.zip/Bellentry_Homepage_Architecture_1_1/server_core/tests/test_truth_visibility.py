from app.services.projections import load_property, public_projection

def test_public_projection_reports_open_conflict(db):
    p=public_projection(load_property(db,"BTY-HH-GF-000001"))
    assert p["open_conflicts"]==1
    assert p["bellentry_id"]=="BTY-HH-GF-000001"
