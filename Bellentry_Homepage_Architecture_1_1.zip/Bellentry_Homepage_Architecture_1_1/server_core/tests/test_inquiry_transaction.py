from sqlalchemy import select, func
from app.schemas import InquiryCreate
from app.services.inquiries import create_inquiry, InquiryError
from app.models import Person, Journey, JourneyEvent, Inquiry, RoleAssignment, AuditEvent, Task

def test_inquiry_creates_connected_domain_objects(db):
    j=create_inquiry(db,InquiryCreate(property_id="BTY-HH-GF-000001",name="Test Person",email="test@example.com",message="Ich möchte die Wohnung besichtigen.",consent=True))
    assert j.state=="interest_received"
    assert db.scalar(select(func.count()).select_from(Person))==1
    assert db.scalar(select(func.count()).select_from(RoleAssignment))==1
    assert db.scalar(select(func.count()).select_from(Journey))==1
    assert db.scalar(select(func.count()).select_from(JourneyEvent))==1
    assert db.scalar(select(func.count()).select_from(Inquiry))==1
    assert db.scalar(select(func.count()).select_from(AuditEvent))==1
    assert db.scalar(select(func.count()).select_from(Task))==1

def test_inquiry_without_consent_writes_nothing(db):
    try:
        create_inquiry(db,InquiryCreate(property_id="BTY-HH-GF-000001",name="Test Person",email="test@example.com",message="Bitte melden.",consent=False))
    except InquiryError:
        db.rollback()
    assert db.scalar(select(func.count()).select_from(Person))==0
    assert db.scalar(select(func.count()).select_from(Journey))==0
