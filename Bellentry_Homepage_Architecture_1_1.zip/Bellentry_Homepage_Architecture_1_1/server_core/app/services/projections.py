from sqlalchemy.orm import Session, selectinload
from sqlalchemy import select
from ..models import Property, PropertyFact, Conflict

class PropertyNotFound(Exception): pass

def load_property(db: Session, bellentry_id: str) -> Property:
    stmt=(select(Property)
          .where(Property.bellentry_id==bellentry_id)
          .options(
              selectinload(Property.facts).selectinload(PropertyFact.evidence),
              selectinload(Property.conflicts).selectinload(Conflict.facts),
              selectinload(Property.evidence),
              selectinload(Property.documents),
              selectinload(Property.media),
              selectinload(Property.publication),
          ))
    p=db.execute(stmt).scalar_one_or_none()
    if not p: raise PropertyNotFound(bellentry_id)
    return p

def fact_dict(f):
    return {
        "key": f.fact_key, "label": f.label, "value": f.display_value,
        "truth_state": f.truth_state, "resolution_state": f.resolution_state,
        "evidence": [{"key":e.evidence_key,"title":e.title,"source_type":e.source_type,"state":e.verification_state,"notes":e.notes} for e in f.evidence]
    }

def public_projection(p: Property):
    pub=sorted([f for f in p.facts if f.public_visible], key=lambda x:(x.sort_order,x.id))
    return {
        "bellentry_id":p.bellentry_id,"slug":p.slug,"title":p.title,
        "address":p.address_display,"verification_state":p.verification_state,
        "price":p.publication.monthly_total_eur if p.publication else None,
        "available_from":p.publication.available_from if p.publication else None,
        "description":p.publication.public_copy if p.publication else "",
        "media":[{"role":m.role,"storage_key":m.storage_key,"alt":m.alt_text,"rights_state":m.rights_state} for m in p.media],
        "facts":[fact_dict(f) for f in pub],
        "open_conflicts":len([c for c in p.conflicts if c.state=="open"]),
    }

def passport_projection(p: Property):
    return {
        **public_projection(p),
        "facts":[fact_dict(f) for f in sorted(p.facts,key=lambda x:(x.sort_order,x.id))],
        "evidence":[{"key":e.evidence_key,"title":e.title,"source_type":e.source_type,"state":e.verification_state,"notes":e.notes} for e in p.evidence],
        "conflicts":[{"key":c.conflict_key,"title":c.title,"state":c.state,"severity":c.severity,"next_action":c.next_action,"facts":[fact_dict(f) for f in c.facts]} for c in p.conflicts],
        "documents":[{"key":d.document_key,"title":d.title,"type":d.document_type,"state":d.lifecycle_state} for d in p.documents],
    }
