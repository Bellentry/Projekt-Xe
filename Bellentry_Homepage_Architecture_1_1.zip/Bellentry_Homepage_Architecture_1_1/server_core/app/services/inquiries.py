from uuid import uuid4
from sqlalchemy import select
from sqlalchemy.orm import Session
from ..models import Property, Person, RoleAssignment, Journey, JourneyEvent, Inquiry, AuditEvent, Task
from ..schemas import InquiryCreate

class InquiryError(Exception): pass

def create_inquiry(db: Session, payload: InquiryCreate):
    if not payload.consent: raise InquiryError("Einwilligung erforderlich")
    if payload.company.strip(): raise InquiryError("Ungültige Anfrage")
    prop=db.execute(select(Property).where(Property.bellentry_id==payload.property_id)).scalar_one_or_none()
    if not prop: raise InquiryError("Immobilie nicht gefunden")
    email=payload.email.strip().lower()
    person=db.execute(select(Person).where(Person.email_normalized==email)).scalar_one_or_none()
    if not person:
        person=Person(display_name=payload.name.strip(),email=str(payload.email),email_normalized=email,consent_state="inquiry_only")
        db.add(person); db.flush()
    role=db.execute(select(RoleAssignment).where(RoleAssignment.person_id==person.id,RoleAssignment.role_type=="prospect",RoleAssignment.scope_id==prop.bellentry_id)).scalar_one_or_none()
    if not role:
        db.add(RoleAssignment(person_id=person.id,role_type="prospect",scope_type="property",scope_id=prop.bellentry_id,status="active"))
    key=f"JRN-{uuid4().hex[:12].upper()}"
    journey=Journey(journey_key=key,person_id=person.id,property_id=prop.id,journey_type="rental_inquiry",state="interest_received",next_action="Anfrage durch Bellentry prüfen")
    db.add(journey); db.flush()
    db.add(Inquiry(journey_id=journey.id,message=payload.message.strip()))
    db.add(JourneyEvent(journey_id=journey.id,event_type="interest_received",description="Interesse an der Immobilie eingegangen"))
    db.add(Task(task_key=f"TSK-{uuid4().hex[:12].upper()}",journey_id=journey.id,title="Anfrage prüfen und nächsten Schritt festlegen",state="open",assignee_type="operator_queue"))
    db.add(AuditEvent(event_type="inquiry.created",actor_type="person",actor_id=str(person.id),subject_type="journey",subject_id=key,detail=prop.bellentry_id))
    try:
        db.commit(); db.refresh(journey)
        return journey
    except Exception:
        db.rollback()
        raise
