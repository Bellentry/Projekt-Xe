import secrets
from fastapi import HTTPException, Request

def ensure_csrf(request: Request, token: str):
    expected=request.session.get("csrf")
    if not expected or not secrets.compare_digest(expected, token):
        raise HTTPException(status_code=403, detail="Ungültige Formularsitzung")
