from pathlib import Path
import secrets
from fastapi import FastAPI, Depends, Form, HTTPException, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.middleware.sessions import SessionMiddleware
from sqlalchemy.orm import Session
from sqlalchemy import select
from .config import settings, validate_settings
from .db import Base, engine, get_db
from .models import Journey
from .schemas import InquiryCreate
from .services.projections import load_property, public_projection, passport_projection, PropertyNotFound
from .services.inquiries import create_inquiry, InquiryError
from .services.security import ensure_csrf
from .seed import seed

APP_DIR=Path(__file__).parent
validate_settings()
app=FastAPI(title="Bellentry Living System",version="0.5.2",docs_url="/internal/api-docs" if settings.environment=="development" else None)
app.add_middleware(SessionMiddleware, secret_key=settings.session_secret, https_only=settings.environment!="development", same_site="lax")
app.mount("/static",StaticFiles(directory=APP_DIR/"static"),name="static")

@app.middleware("http")
async def security_headers(request, call_next):
    response=await call_next(request)
    response.headers["X-Content-Type-Options"]="nosniff"
    response.headers["X-Frame-Options"]="DENY"
    response.headers["Referrer-Policy"]="strict-origin-when-cross-origin"
    response.headers["Permissions-Policy"]="geolocation=(), camera=(), microphone=()"
    response.headers["Content-Security-Policy"]="default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'; form-action 'self'"
    if settings.environment=="production": response.headers["Strict-Transport-Security"]="max-age=31536000; includeSubDomains"
    return response
templates=Jinja2Templates(directory=str(APP_DIR/"templates"))

@app.on_event("startup")
def startup():
    # Development convenience only. Production schema changes must run through Alembic.
    if settings.environment == "development":
        Base.metadata.create_all(engine); seed()

def csrf(request:Request):
    token=request.session.get("csrf")
    if not token:
        token=secrets.token_urlsafe(32); request.session["csrf"]=token
    return token

def render(request:Request,name:str,**ctx):
    return templates.TemplateResponse(request=request,name=name,context={"request":request,"csrf_token":csrf(request),**ctx})

@app.get("/healthz")
def health(): return {"status":"ok","version":"0.5.2"}

@app.get("/",response_class=HTMLResponse)
def home(request:Request,db:Session=Depends(get_db)):
    p=load_property(db,"BTY-HH-GF-000001")
    hero=public_projection(p)
    hero_energy=next((f for f in hero["facts"] if f["key"]=="energy_intensity" and f["truth_state"]=="documented"),None)
    hero_energy_values=[f for f in hero["facts"] if f["key"]=="energy_intensity"]
    return render(request,"home.html",hero=hero,hero_energy=hero_energy,hero_energy_values=hero_energy_values)

@app.get("/immobilien/gross-flottbek/",response_class=HTMLResponse)
def property_page(request:Request,db:Session=Depends(get_db)):
    p=load_property(db,"BTY-HH-GF-000001")
    return render(request,"property.html",p=public_projection(p))

@app.get("/immobilien/gross-flottbek/passport/",response_class=HTMLResponse)
def passport_page(request:Request,db:Session=Depends(get_db)):
    p=load_property(db,"BTY-HH-GF-000001")
    return render(request,"passport.html",p=passport_projection(p))

@app.get("/mein-bellentry/",response_class=HTMLResponse)
def my_bellentry(request:Request,db:Session=Depends(get_db)):
    journey=None
    key=request.session.get("journey_key")
    if key:
        journey=db.execute(select(Journey).where(Journey.journey_key==key)).scalar_one_or_none()
    return render(request,"my.html",journey=journey)

@app.get("/control/property/gross-flottbek/",response_class=HTMLResponse)
def control_preview(request:Request,db:Session=Depends(get_db)):
    if not (settings.control_preview and settings.environment=="development"):
        raise HTTPException(status_code=404)
    p=load_property(db,"BTY-HH-GF-000001")
    return render(request,"control.html",p=passport_projection(p))

@app.post("/inquiries/gross-flottbek/")
def inquiry_submit(request:Request,
    csrf_token:str=Form(...),name:str=Form(...),email:str=Form(...),message:str=Form(...),consent:bool=Form(False),company:str=Form(""),db:Session=Depends(get_db)):
    ensure_csrf(request,csrf_token)
    try:
        payload=InquiryCreate(property_id="BTY-HH-GF-000001",name=name,email=email,message=message,consent=consent,company=company)
        journey=create_inquiry(db,payload)
    except (InquiryError,ValueError) as exc:
        db.rollback(); raise HTTPException(status_code=422,detail=str(exc))
    request.session["journey_key"]=journey.journey_key
    return RedirectResponse("/mein-bellentry/?created=1",status_code=303)

@app.get("/api/v1/properties/{bellentry_id}")
def api_property(bellentry_id:str,db:Session=Depends(get_db)):
    try: return public_projection(load_property(db,bellentry_id))
    except PropertyNotFound: raise HTTPException(status_code=404,detail="Property not found")

@app.get("/api/v1/properties/{bellentry_id}/passport")
def api_passport(bellentry_id:str,db:Session=Depends(get_db)):
    try: return passport_projection(load_property(db,bellentry_id))
    except PropertyNotFound: raise HTTPException(status_code=404,detail="Property not found")
