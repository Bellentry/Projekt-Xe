from pydantic import BaseModel, Field, field_validator
import re

class InquiryCreate(BaseModel):
    property_id: str
    name: str = Field(min_length=2, max_length=180)
    email: str = Field(min_length=5, max_length=320)
    message: str = Field(min_length=5, max_length=4000)
    consent: bool
    company: str = ""

    @field_validator("email")
    @classmethod
    def email_shape(cls, v: str):
        v=v.strip()
        if not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", v):
            raise ValueError("Ungültige E-Mail-Adresse")
        return v

class InquiryResult(BaseModel):
    journey_key: str
    state: str
    next_action: str
