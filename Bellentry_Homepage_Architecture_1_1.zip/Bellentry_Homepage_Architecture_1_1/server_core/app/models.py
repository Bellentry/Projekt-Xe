from __future__ import annotations
from datetime import datetime, timezone
from sqlalchemy import String, Integer, Boolean, DateTime, ForeignKey, Text, UniqueConstraint, Table, Column
from sqlalchemy.orm import Mapped, mapped_column, relationship
from .db import Base

fact_evidence = Table(
    "fact_evidence", Base.metadata,
    Column("fact_id", ForeignKey("property_facts.id", ondelete="CASCADE"), primary_key=True),
    Column("evidence_id", ForeignKey("evidence.id", ondelete="CASCADE"), primary_key=True),
)
conflict_facts = Table(
    "conflict_facts", Base.metadata,
    Column("conflict_id", ForeignKey("conflicts.id", ondelete="CASCADE"), primary_key=True),
    Column("fact_id", ForeignKey("property_facts.id", ondelete="CASCADE"), primary_key=True),
)

class Property(Base):
    __tablename__ = "properties"
    id: Mapped[int] = mapped_column(primary_key=True)
    bellentry_id: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    slug: Mapped[str] = mapped_column(String(160), unique=True, index=True)
    title: Mapped[str] = mapped_column(String(255))
    address_display: Mapped[str] = mapped_column(String(255))
    city: Mapped[str] = mapped_column(String(120), index=True)
    district: Mapped[str] = mapped_column(String(120), index=True)
    verification_state: Mapped[str] = mapped_column(String(40), default="partial_conflict")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    facts: Mapped[list[PropertyFact]] = relationship(back_populates="property", cascade="all, delete-orphan")
    evidence: Mapped[list[Evidence]] = relationship(back_populates="property", cascade="all, delete-orphan")
    conflicts: Mapped[list[Conflict]] = relationship(back_populates="property", cascade="all, delete-orphan")
    documents: Mapped[list[Document]] = relationship(back_populates="property", cascade="all, delete-orphan")
    media: Mapped[list[MediaAsset]] = relationship(back_populates="property", cascade="all, delete-orphan", order_by="MediaAsset.sort_order")
    publication: Mapped[Publication | None] = relationship(back_populates="property", cascade="all, delete-orphan", uselist=False)

class Evidence(Base):
    __tablename__ = "evidence"
    id: Mapped[int] = mapped_column(primary_key=True)
    evidence_key: Mapped[str] = mapped_column(String(120), unique=True)
    property_id: Mapped[int] = mapped_column(ForeignKey("properties.id", ondelete="CASCADE"), index=True)
    title: Mapped[str] = mapped_column(String(255))
    source_type: Mapped[str] = mapped_column(String(60))
    verification_state: Mapped[str] = mapped_column(String(60))
    notes: Mapped[str] = mapped_column(Text, default="")
    property: Mapped[Property] = relationship(back_populates="evidence")
    facts: Mapped[list[PropertyFact]] = relationship(secondary=fact_evidence, back_populates="evidence")

class PropertyFact(Base):
    __tablename__ = "property_facts"
    __table_args__ = (UniqueConstraint("property_id", "fact_key", "value_key", name="uq_fact_value"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    property_id: Mapped[int] = mapped_column(ForeignKey("properties.id", ondelete="CASCADE"), index=True)
    fact_key: Mapped[str] = mapped_column(String(120), index=True)
    value_key: Mapped[str] = mapped_column(String(120), default="primary")
    label: Mapped[str] = mapped_column(String(180))
    display_value: Mapped[str] = mapped_column(String(255))
    truth_state: Mapped[str] = mapped_column(String(60))
    resolution_state: Mapped[str] = mapped_column(String(60), default="resolved")
    public_visible: Mapped[bool] = mapped_column(Boolean, default=True)
    sort_order: Mapped[int] = mapped_column(Integer, default=0)
    property: Mapped[Property] = relationship(back_populates="facts")
    evidence: Mapped[list[Evidence]] = relationship(secondary=fact_evidence, back_populates="facts")
    conflicts: Mapped[list[Conflict]] = relationship(secondary=conflict_facts, back_populates="facts")

class Conflict(Base):
    __tablename__ = "conflicts"
    id: Mapped[int] = mapped_column(primary_key=True)
    conflict_key: Mapped[str] = mapped_column(String(120), unique=True)
    property_id: Mapped[int] = mapped_column(ForeignKey("properties.id", ondelete="CASCADE"), index=True)
    title: Mapped[str] = mapped_column(String(255))
    state: Mapped[str] = mapped_column(String(40), default="open")
    severity: Mapped[str] = mapped_column(String(40), default="material")
    next_action: Mapped[str] = mapped_column(Text)
    resolution_note: Mapped[str | None] = mapped_column(Text, nullable=True)
    property: Mapped[Property] = relationship(back_populates="conflicts")
    facts: Mapped[list[PropertyFact]] = relationship(secondary=conflict_facts, back_populates="conflicts")

class Document(Base):
    __tablename__ = "documents"
    id: Mapped[int] = mapped_column(primary_key=True)
    document_key: Mapped[str] = mapped_column(String(120), unique=True)
    property_id: Mapped[int] = mapped_column(ForeignKey("properties.id", ondelete="CASCADE"), index=True)
    title: Mapped[str] = mapped_column(String(255))
    document_type: Mapped[str] = mapped_column(String(80))
    lifecycle_state: Mapped[str] = mapped_column(String(60))
    property: Mapped[Property] = relationship(back_populates="documents")


class MediaAsset(Base):
    __tablename__ = "media_assets"
    id: Mapped[int] = mapped_column(primary_key=True)
    media_key: Mapped[str] = mapped_column(String(120), unique=True)
    property_id: Mapped[int] = mapped_column(ForeignKey("properties.id", ondelete="CASCADE"), index=True)
    role: Mapped[str] = mapped_column(String(60))
    storage_key: Mapped[str] = mapped_column(String(255))
    alt_text: Mapped[str] = mapped_column(String(255), default="")
    rights_state: Mapped[str] = mapped_column(String(60), default="reviewed")
    sort_order: Mapped[int] = mapped_column(Integer, default=0)
    property: Mapped[Property] = relationship(back_populates="media")

class Publication(Base):
    __tablename__ = "publications"
    id: Mapped[int] = mapped_column(primary_key=True)
    property_id: Mapped[int] = mapped_column(ForeignKey("properties.id", ondelete="CASCADE"), unique=True)
    public_status: Mapped[str] = mapped_column(String(40), default="preview")
    monthly_total_eur: Mapped[int] = mapped_column(Integer)
    available_from: Mapped[str] = mapped_column(String(120))
    public_copy: Mapped[str] = mapped_column(Text)
    property: Mapped[Property] = relationship(back_populates="publication")

class Person(Base):
    __tablename__ = "people"
    id: Mapped[int] = mapped_column(primary_key=True)
    display_name: Mapped[str] = mapped_column(String(180))
    email: Mapped[str] = mapped_column(String(320))
    email_normalized: Mapped[str] = mapped_column(String(320), unique=True, index=True)
    consent_state: Mapped[str] = mapped_column(String(40), default="inquiry_only")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    roles: Mapped[list[RoleAssignment]] = relationship(back_populates="person", cascade="all, delete-orphan")
    journeys: Mapped[list[Journey]] = relationship(back_populates="person", cascade="all, delete-orphan")

class RoleAssignment(Base):
    __tablename__ = "role_assignments"
    id: Mapped[int] = mapped_column(primary_key=True)
    person_id: Mapped[int] = mapped_column(ForeignKey("people.id", ondelete="CASCADE"), index=True)
    role_type: Mapped[str] = mapped_column(String(60))
    scope_type: Mapped[str] = mapped_column(String(60))
    scope_id: Mapped[str] = mapped_column(String(120))
    status: Mapped[str] = mapped_column(String(40), default="active")
    person: Mapped[Person] = relationship(back_populates="roles")

class Journey(Base):
    __tablename__ = "journeys"
    id: Mapped[int] = mapped_column(primary_key=True)
    journey_key: Mapped[str] = mapped_column(String(120), unique=True)
    person_id: Mapped[int] = mapped_column(ForeignKey("people.id", ondelete="CASCADE"), index=True)
    property_id: Mapped[int] = mapped_column(ForeignKey("properties.id", ondelete="CASCADE"), index=True)
    journey_type: Mapped[str] = mapped_column(String(60))
    state: Mapped[str] = mapped_column(String(60))
    next_action: Mapped[str] = mapped_column(String(255))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    person: Mapped[Person] = relationship(back_populates="journeys")
    property: Mapped[Property] = relationship()
    events: Mapped[list[JourneyEvent]] = relationship(back_populates="journey", cascade="all, delete-orphan", order_by="JourneyEvent.created_at")
    tasks: Mapped[list[Task]] = relationship(back_populates="journey", cascade="all, delete-orphan", order_by="Task.created_at")


class Task(Base):
    __tablename__ = "tasks"
    id: Mapped[int] = mapped_column(primary_key=True)
    task_key: Mapped[str] = mapped_column(String(120), unique=True)
    journey_id: Mapped[int] = mapped_column(ForeignKey("journeys.id", ondelete="CASCADE"), index=True)
    title: Mapped[str] = mapped_column(String(255))
    state: Mapped[str] = mapped_column(String(40), default="open")
    assignee_type: Mapped[str] = mapped_column(String(60), default="operator_queue")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    journey: Mapped[Journey] = relationship(back_populates="tasks")

class JourneyEvent(Base):
    __tablename__ = "journey_events"
    id: Mapped[int] = mapped_column(primary_key=True)
    journey_id: Mapped[int] = mapped_column(ForeignKey("journeys.id", ondelete="CASCADE"), index=True)
    event_type: Mapped[str] = mapped_column(String(80))
    description: Mapped[str] = mapped_column(String(255))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    journey: Mapped[Journey] = relationship(back_populates="events")

class Inquiry(Base):
    __tablename__ = "inquiries"
    id: Mapped[int] = mapped_column(primary_key=True)
    journey_id: Mapped[int] = mapped_column(ForeignKey("journeys.id", ondelete="CASCADE"), unique=True)
    message: Mapped[str] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

class AuditEvent(Base):
    __tablename__ = "audit_events"
    id: Mapped[int] = mapped_column(primary_key=True)
    event_type: Mapped[str] = mapped_column(String(100), index=True)
    actor_type: Mapped[str] = mapped_column(String(60))
    actor_id: Mapped[str | None] = mapped_column(String(120), nullable=True)
    subject_type: Mapped[str] = mapped_column(String(60))
    subject_id: Mapped[str] = mapped_column(String(120))
    detail: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
