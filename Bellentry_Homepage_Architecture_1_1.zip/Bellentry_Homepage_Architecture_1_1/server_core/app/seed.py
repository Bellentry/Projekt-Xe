from sqlalchemy import select
from .db import SessionLocal
from .models import Property, PropertyFact, Evidence, Conflict, Document, Publication, MediaAsset

def seed_db(db):
    if db.execute(select(Property).where(Property.bellentry_id=="BTY-HH-GF-000001")).scalar_one_or_none():
        return
    p=Property(bellentry_id="BTY-HH-GF-000001",slug="gross-flottbek",title="Helle 2-Zimmer-Wohnung in Groß Flottbek",address_display="Hamburg · Groß Flottbek",city="Hamburg",district="Groß Flottbek",verification_state="partial_conflict")
    db.add(p); db.flush()
    floor=Evidence(evidence_key="EV-FLOORPLAN",property_id=p.id,title="Grundriss",source_type="primary_document",verification_state="reviewed",notes="Unterlage stützt die Flächenangabe.")
    energy=Evidence(evidence_key="EV-ENERGY",property_id=p.id,title="GEG-/Energieunterlage",source_type="primary_document",verification_state="reviewed_conflict",notes="Dokument nennt 93,1 kWh/(m²·a), Klasse C.")
    statement=Evidence(evidence_key="EV-OWNER-STATEMENT",property_id=p.id,title="Schriftliche Mitteilung",source_type="owner_statement",verification_state="conflicts_with_primary",notes="Mitteilung nennt 118 kWh/(m²·a), Klasse D.")
    listing=Evidence(evidence_key="EV-LISTING",property_id=p.id,title="Objektdaten / Vermieterangaben",source_type="owner_statement",verification_state="partially_reviewed",notes="Ausstattung und Lageangaben; Primärbelege je Fakt unterschiedlich.")
    db.add_all([floor,energy,statement,listing]); db.flush()
    facts=[
      PropertyFact(property_id=p.id,fact_key="rooms",value_key="primary",label="Zimmer",display_value="2 Zimmer",truth_state="documented",resolution_state="resolved",sort_order=1),
      PropertyFact(property_id=p.id,fact_key="living_area_sqm",value_key="primary",label="Wohnfläche",display_value="~51 m²",truth_state="documented",resolution_state="resolved",sort_order=2),
      PropertyFact(property_id=p.id,fact_key="floor",value_key="primary",label="Etage",display_value="2. Etage",truth_state="user_supplied",resolution_state="resolved",sort_order=3),
      PropertyFact(property_id=p.id,fact_key="energy_intensity",value_key="primary_document",label="Energiekennwert · Dokument",display_value="93,1 kWh/(m²·a) · Klasse C",truth_state="documented",resolution_state="unresolved",sort_order=4),
      PropertyFact(property_id=p.id,fact_key="energy_intensity",value_key="owner_statement",label="Energiekennwert · Mitteilung",display_value="118 kWh/(m²·a) · Klasse D",truth_state="user_supplied",resolution_state="unresolved",sort_order=5),
      PropertyFact(property_id=p.id,fact_key="heating",value_key="primary",label="Heizung",display_value="Fußbodenheizung",truth_state="user_supplied",resolution_state="resolved",sort_order=6),
      PropertyFact(property_id=p.id,fact_key="flooring",value_key="primary",label="Boden",display_value="Parkett · Fliesen",truth_state="user_supplied",resolution_state="resolved",sort_order=7),
    ]
    db.add_all(facts); db.flush()
    facts[1].evidence.append(floor); facts[3].evidence.append(energy); facts[4].evidence.append(statement)
    for f in [facts[0],facts[2],facts[5],facts[6]]: f.evidence.append(listing)
    c=Conflict(conflict_key="CF-ENERGY-001",property_id=p.id,title="Widersprüchliche Energiedaten",state="open",severity="material",next_action="Primärunterlage und schriftliche Mitteilung fachlich abgleichen; bis dahin beide Werte sichtbar halten.")
    c.facts.extend([facts[3],facts[4]]); db.add(c)
    db.add_all([
      MediaAsset(media_key="MEDIA-GF-01",property_id=p.id,role="hero",storage_key="gross-flottbek-01-1200.webp",alt_text="Helle 2-Zimmer-Wohnung in Groß Flottbek",rights_state="reviewed",sort_order=1),
      MediaAsset(media_key="MEDIA-GF-02",property_id=p.id,role="gallery",storage_key="gross-flottbek-02-1200.webp",alt_text="Weitere Ansicht der Wohnung in Groß Flottbek",rights_state="reviewed",sort_order=2),
      MediaAsset(media_key="MEDIA-GF-03",property_id=p.id,role="gallery",storage_key="gross-flottbek-03-1200.webp",alt_text="Weitere Ansicht der Wohnung in Groß Flottbek",rights_state="reviewed",sort_order=3),
      Document(document_key="DOC-FLOORPLAN",property_id=p.id,title="Grundriss",document_type="floorplan",lifecycle_state="reviewed"),
      Document(document_key="DOC-ENERGY",property_id=p.id,title="Energieunterlage",document_type="energy_certificate",lifecycle_state="reviewed_conflict"),
    ])
    db.add(Publication(property_id=p.id,public_status="preview",monthly_total_eur=1140,available_from="November 2026",public_copy="Charmante 2-Zimmer-Wohnung in der End-Etage eines gepflegten Mehrfamilienhauses mit Balkon, Dachterrasse, Einbauküche, Eichenparkett und individuell regulierbarer Fußbodenheizung."))
    db.commit()

def seed():
    db=SessionLocal()
    try: seed_db(db)
    finally: db.close()

if __name__ == "__main__": seed()
