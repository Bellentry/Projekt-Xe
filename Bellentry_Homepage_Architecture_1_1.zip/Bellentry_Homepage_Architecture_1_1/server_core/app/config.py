from dataclasses import dataclass
import os

@dataclass(frozen=True)
class Settings:
    database_url: str = os.getenv("BELLENTRY_DATABASE_URL", "sqlite:///./bellentry.db")
    session_secret: str = os.getenv("BELLENTRY_SESSION_SECRET", "dev-only-change-me")
    environment: str = os.getenv("BELLENTRY_ENV", "development")
    control_preview: bool = os.getenv("BELLENTRY_CONTROL_PREVIEW", "false").lower() == "true"

settings = Settings()


def validate_settings():
    if settings.environment == "production" and settings.session_secret == "dev-only-change-me":
        raise RuntimeError("BELLENTRY_SESSION_SECRET must be set to a strong non-default value in production")
    if settings.environment == "production" and settings.database_url.startswith("sqlite"):
        raise RuntimeError("Production requires PostgreSQL; SQLite is development-only")
