(()=>{'use strict';
const $=(s,r=document)=>r.querySelector(s);
const cinema=$('[data-cinema]');
if(!cinema||matchMedia('(prefers-reduced-motion: reduce)').matches)return;
const stage=$('[data-stage]',cinema), portal=$('[data-portal]',cinema), sceneNo=$('[data-scene-number]',cinema);
const clamp=x=>Math.max(0,Math.min(1,x));
const smooth=t=>{t=clamp(t);return t*t*(3-2*t)};
const smoother=t=>{t=clamp(t);return t*t*t*(t*(t*6-15)+10)};
const quint=t=>1-Math.pow(1-clamp(t),5);
const phase=(p,a,b,e=smoother)=>e(clamp((p-a)/(b-a)));
const mix=(a,b,t)=>a+(b-a)*t;
const mixState=(a,b,t)=>({x:mix(a.x,b.x,t),y:mix(a.y,b.y,t),w:mix(a.w,b.w,t),h:mix(a.h,b.h,t)});
const desktop={arrival:{x:68,y:15,w:22,h:70},full:{x:0,y:0,w:100,h:100},structure:{x:29,y:10,w:42,h:80},evidence:{x:6,y:14,w:36,h:72}};
const mobile={arrival:{x:12,y:14,w:76,h:36},full:{x:0,y:0,w:100,h:100},structure:{x:9,y:9,w:82,h:49},evidence:{x:10,y:8,w:80,h:42}};
let manual=null,target=0,current=0,raf=0,last=performance.now();
function rawProgress(){const r=cinema.getBoundingClientRect(), travel=Math.max(1,cinema.offsetHeight-innerHeight);return clamp(-r.top/travel)}
function geometry(p){const s=innerWidth<=640?mobile:desktop;if(p<.24)return mixState(s.arrival,s.full,quint(phase(p,.055,.24,t=>t)));if(p<.55)return s.full;if(p<.72)return mixState(s.full,s.structure,smooth(phase(p,.55,.72,t=>t)));if(p<.88)return mixState(s.structure,s.evidence,smooth(phase(p,.72,.88,t=>t)));return s.evidence}
function setv(k,v){stage.style.setProperty(k,typeof v==='number'?v.toFixed(4):v)}
function render(p){p=clamp(p); const g=geometry(p);
  const arrival=1-phase(p,.075,.19,quint);
  const voidAlpha=1-phase(p,.17,.31,smooth);
  const darkPlan=phase(p,.13,.27,quint)*(1-phase(p,.49,.60,smooth));
  const paper=phase(p,.47,.62,smooth)*(1-phase(p,.89,.96,smooth));
  const paperPlan=phase(p,.52,.64,quint)*(1-phase(p,.90,.96,smooth));
  const spaceCopy=phase(p,.29,.37,quint)*(1-phase(p,.47,.55,smooth));
  const structureCopy=phase(p,.61,.69,quint)*(1-phase(p,.73,.79,smooth));
  const evidence=phase(p,.77,.83,quint)*(1-phase(p,.90,.95,smooth));
  const action=phase(p,.915,.975,quint);
  const flat=phase(p,.57,.81,smoother);
  const planScale=mix(.78,1.04,flat);
  setv('--p',p);setv('--arrival',arrival);setv('--void-alpha',voidAlpha);setv('--dark-plan',darkPlan);setv('--paper-alpha',paper);setv('--paper-plan',paperPlan);setv('--space-copy',spaceCopy);setv('--structure-copy',structureCopy);setv('--evidence',evidence);setv('--action',action);
  setv('--portal-x',`${g.x}vw`);setv('--portal-y',`${g.y}vh`);setv('--portal-w',`${g.w}vw`);setv('--portal-h',`${g.h}vh`);
  setv('--plan-rx',`${mix(64,0,flat).toFixed(2)}deg`);setv('--plan-rz',`${mix(-20,0,flat).toFixed(2)}deg`);setv('--plan-scale',planScale.toFixed(4));setv('--portal-border',Math.max(0,1-paper-action));setv('--identity',Math.max(0,1-phase(p,.42,.53,smooth)));
  portal.style.opacity=String(Math.max(0,1-action*1.2));
  if(sceneNo)sceneNo.textContent=String(p<.24?1:p<.55?2:p<.76?3:p<.91?4:5).padStart(2,'0');
}
function loop(now){const dt=Math.min(.05,(now-last)/1000);last=now;target=manual===null?rawProgress():manual;const alpha=1-Math.exp(-dt*11);current+=(target-current)*alpha;render(current);if(manual===null&&Math.abs(target-current)>.00015){raf=requestAnimationFrame(loop)}else raf=0}
function kick(){target=manual===null?rawProgress():manual;if(!raf){last=performance.now();raf=requestAnimationFrame(loop)}}
addEventListener('scroll',kick,{passive:true});addEventListener('resize',()=>{target=manual===null?rawProgress():manual;current=target;render(current)},{passive:true});
current=target=rawProgress();render(current);
window.__BELLENTRY_CINEMA_SET=p=>{manual=clamp(Number(p)||0);target=current=manual;render(manual)};
window.__BELLENTRY_CINEMA_RELEASE=()=>{manual=null;target=current=rawProgress();render(current)};
})();
