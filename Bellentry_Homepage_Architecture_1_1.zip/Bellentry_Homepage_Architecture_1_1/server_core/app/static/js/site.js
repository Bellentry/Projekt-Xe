(()=>{'use strict';
const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>Array.from(r.querySelectorAll(s));
const body=document.body, menu=$('[data-menu-panel]'), menuBtn=$('[data-menu-button]'), shell=$('#page-shell');
let returnFocus=null;
const menuFocus=()=>menu?$$('a[href],button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])',menu):[];
function openMenu(){returnFocus=document.activeElement;body.classList.add('menu-open');menu?.classList.add('is-open');menu?.removeAttribute('inert');menu?.setAttribute('aria-hidden','false');menuBtn?.setAttribute('aria-expanded','true');menuBtn?.setAttribute('aria-label','Menü schließen');shell?.setAttribute('inert','');setTimeout(()=>menuFocus()[0]?.focus(),160)}
function closeMenu(){body.classList.remove('menu-open');menu?.classList.remove('is-open');menu?.setAttribute('inert','');menu?.setAttribute('aria-hidden','true');menuBtn?.setAttribute('aria-expanded','false');menuBtn?.setAttribute('aria-label','Menü öffnen');shell?.removeAttribute('inert');returnFocus?.focus?.()}
menuBtn?.addEventListener('click',()=>body.classList.contains('menu-open')?closeMenu():openMenu());
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&body.classList.contains('menu-open')){e.preventDefault();closeMenu()}if(e.key==='Tab'&&body.classList.contains('menu-open')){const f=menuFocus();if(!f.length)return;const first=f[0],last=f[f.length-1];if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus()}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus()}}});
})();
