from pathlib import Path
from playwright.sync_api import sync_playwright
from bs4 import BeautifulSoup
import base64,mimetypes,json
ROOT=Path(__file__).resolve().parents[1]; CSS=(ROOT/'assets/css/site.css').read_text(); JS=(ROOT/'assets/js/site.js').read_text()
def uri(p):
 m=mimetypes.guess_type(p.name)[0] or 'application/octet-stream'; return 'data:'+m+';base64,'+base64.b64encode(p.read_bytes()).decode()
def inline(path):
 s=BeautifulSoup(path.read_text(),'html.parser')
 for l in s.find_all('link',rel='stylesheet'):
  x=s.new_tag('style'); x.string=CSS; l.replace_with(x)
 for sc in s.find_all('script',src=True):
  x=s.new_tag('script'); x.string=JS; sc.replace_with(x)
 for im in s.find_all('img',src=True):
  p=(path.parent/im['src']).resolve()
  if p.exists(): im['src']=uri(p)
 return str(s)
errors=[]; stats=[]
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 for width,height in [(1440,1000),(390,844),(320,780)]:
  pg=b.new_page(viewport={'width':width,'height':height}); logs=[]; pg.on('console',lambda m: logs.append(m.text) if m.type=='error' else None)
  for f in sorted(ROOT.glob('*.html')):
   logs.clear(); pg.set_content(inline(f),wait_until='load'); pg.wait_for_timeout(25)
   ov=pg.evaluate('document.documentElement.scrollWidth-document.documentElement.clientWidth')
   if ov>1: errors.append(f'{f.name} @{width}: overflow {ov}px')
   if logs: errors += [f'{f.name} @{width}: console {x}' for x in logs]
   stats.append({'page':f.name,'width':width,'overflow':ov,'console_errors':len(logs)})
  pg.close()
 b.close()
(ROOT/'qa'/'ROUTE_RENDER_QA.json').write_text(json.dumps({'stats':stats,'errors':errors},indent=2,ensure_ascii=False))
md=['# Route Render QA','',f'- Pages: {len(list(ROOT.glob("*.html")))}', '- Viewports: 1440×1000, 390×844, 320×780', f'- Render cases: {len(stats)}', f'- Errors: {len(errors)}','']
if errors: md += ['## Errors']+[f'- {e}' for e in errors]
else: md += ['## Result','PASS — all 20 pages rendered at all three viewport widths with no horizontal overflow and no console errors in the isolated Chromium renderer.']
(ROOT/'qa'/'ROUTE_RENDER_QA.md').write_text('\n'.join(md))
print(json.dumps({'render_cases':len(stats),'errors':errors},ensure_ascii=False))
raise SystemExit(1 if errors else 0)
