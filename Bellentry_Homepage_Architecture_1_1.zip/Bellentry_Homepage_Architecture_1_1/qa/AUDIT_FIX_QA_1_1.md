# Audit Fix QA 1.1

## Passed in this build environment
- `node --check assets/js/site.js`: PASS.
- Existing static QA: 0 errors; only six expected warnings for the new Spatial room/hotspot controls because the old checker does not know those new button purposes.
- Server-core pytest: 5/5 PASS.
- 21/21 generated content pages have meta description, canonical, Open Graph and JSON-LD.
- 112/112 images have intrinsic width/height after post-processing.
- Responsive 640/960 WebP derivatives exist for all nine listing images where source dimensions permit them; 22 image occurrences currently expose `srcset`.
- `robots.txt`, `sitemap.xml`, `404.html` exist.
- Production settings now fail fast on the default session secret and SQLite.

## Interaction fixes implemented in code
- Property Check validates radio groups by `name`, so all goal and property-type choices can advance.
- Menu has focus trap, background `inert`, Escape close and focus return.
- Consultation reads `objekt`/`vorhaben` query context and requires name/email/topic/message/consent.
- Search empty state distinguishes Buy and Temporary Living from rental inventory.
- Gallery exposes active state and ArrowLeft/ArrowRight navigation.
- Spatial Phase 1 switches room/access state, media and detail text.

## Browser retest limitation
The bundled Playwright installation in the current execution runtime has no matching Chromium executable, so the new branch-complete browser suite could not be executed here. The previous 1.0 screenshots must therefore NOT be presented as proof of the 1.1 interactions. Browser E2E (Chromium + Safari iOS) remains a release gate.
