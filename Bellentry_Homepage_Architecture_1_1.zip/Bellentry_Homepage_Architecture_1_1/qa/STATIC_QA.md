# Bellentry Homepage Architecture 1.0 — Static QA

- Pages: 21
- Links checked: 760
- Buttons checked: 55
- Errors: 0
- Warnings: 6

## Result
PASS — no missing local targets/assets, duplicate IDs, untyped buttons or public chapter-number artifacts found.

## Warnings
- property-gross-flottbek.html: button purpose not recognized: Wohnen
- property-gross-flottbek.html: button purpose not recognized: Schlafen
- property-gross-flottbek.html: button purpose not recognized: Zugang
- property-gross-flottbek.html: button purpose not recognized: W
- property-gross-flottbek.html: button purpose not recognized: S
- property-gross-flottbek.html: button purpose not recognized: E