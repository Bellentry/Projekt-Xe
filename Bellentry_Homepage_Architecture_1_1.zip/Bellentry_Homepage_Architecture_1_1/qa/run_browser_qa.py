from pathlib import Path
from playwright.sync_api import sync_playwright
import json
ROOT=Path(__file__).resolve().parents[1]
URI=(ROOT/'index.html').as_uri()
results=[]; errors=[]
def check_overflow(page,label):
    ov=page.evaluate('document.documentElement.scrollWidth-document.documentElement.clientWidth')
    results.append(f'{label}: overflow {ov}px')
    if ov>1: errors.append(f'{label}: horizontal overflow {ov}px')
def assert_true(v,msg):
    if not v: errors.append(msg)
with sync_playwright() as p:
    browser=p.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--no-sandbox'])
    # desktop landing
    page=browser.new_page(viewport={"width":1440,"height":1000})
    console=[]; page.on('console',lambda m: console.append(m.text) if m.type=='error' else None)
    page.goto(URI); page.wait_for_timeout(300)
    check_overflow(page,'home desktop')
    page.screenshot(path=str(ROOT/'qa'/'homepage-desktop.png'),full_page=True)
    # Search is visible and submit navigates
    assert_true(page.locator('[data-search-form]').count()==1,'home: search form missing')
    page.locator('[data-search-form] input[name="ort"]').fill('Hamburg')
    with page.expect_navigation(): page.locator('[data-search-form] button[type="submit"]').click()
    assert_true('immobilien.html' in page.url,'hero search did not navigate to immobilien.html')
    page.wait_for_timeout(150)
    assert_true(page.locator('[data-result-count]').inner_text()=='3','search initial result count should be 3')
    # WBS filter functional
    page.locator('[data-filter-form] select[name="zugang"]').select_option('wbs')
    page.locator('[data-filter-form] button[type="submit"]').click()
    page.wait_for_timeout(100)
    assert_true(page.locator('[data-result-count]').inner_text()=='1','WBS filter should return 1 property')
    # Open Rissen link exists and works
    vis=page.locator('[data-property]:not([hidden]) h3 a')
    assert_true(vis.count()==1,'WBS visible card count mismatch')
    with page.expect_navigation(): vis.first.click()
    assert_true('property-rissen-suurheid.html' in page.url,'WBS property card did not open Rissen')
    # gallery functional
    before=page.locator('[data-gallery-main]').get_attribute('src')
    thumbs=page.locator('[data-gallery-thumb]')
    thumbs.nth(1).click(); after=page.locator('[data-gallery-main]').get_attribute('src')
    assert_true(before!=after,'gallery thumb did not change main image')
    # save functional + my bellentry
    save=page.locator('[data-save]').first; save.click(); assert_true(save.inner_text()=='Gemerkt','save button did not toggle')
    page.goto((ROOT/'mein-bellentry.html').as_uri()); page.wait_for_timeout(100)
    assert_true(page.locator('.saved-item').count()==1,'saved property not projected to My Bellentry')
    # Property check flow
    page.goto((ROOT/'property-check.html').as_uri()); page.locator('input[name="goal"][value="vermieten"]').check(); page.locator('[data-check-next]').click();
    page.locator('input[name="kind"][value="wohnung"]').check(); page.locator('[data-check-next]').click();
    page.locator('input[name="docs"][value="grundriss"]').check(); page.locator('[data-check-next]').click();
    assert_true('vermieten' in page.locator('[data-check-result]').inner_text().lower(),'property check result missing goal')
    assert_true(page.locator('[data-check-finish]').is_visible(),'property check finish CTA not visible')
    # contact preview form functional without storage claim
    page.goto((ROOT/'beratung.html').as_uri()); page.select_option('select[name="topic"]',label='Vermieten'); page.fill('textarea[name="message"]','Testanliegen für die Browser-QA.'); page.check('.consent input'); page.locator('[data-preview-contact] button[type="submit"]').click();
    assert_true('keine Kontaktdaten' in page.locator('[data-form-status]').inner_text(),'contact preview did not show honest completion state')
    # menu
    page.goto(URI); page.locator('.menu-toggle').click(); assert_true(page.locator('#menu').is_visible(),'menu did not open'); page.keyboard.press('Escape'); assert_true(not page.locator('#menu').is_visible(),'menu did not close on Escape')
    # cinematic later in page actually progresses
    page.locator('[data-cinematic]').scroll_into_view_if_needed(); page.evaluate("window.scrollBy(0, innerHeight*2)"); page.wait_for_timeout(100)
    cin=float(page.locator('.cinematic-sticky').evaluate("e=>getComputedStyle(e).getPropertyValue('--cinema')||'0'"))
    assert_true(cin>0,'cinematic module did not receive scroll progress')
    if console: errors.extend([f'console: {x}' for x in console])
    # mobile landing
    mob=browser.new_page(viewport={"width":390,"height":844})
    mconsole=[]; mob.on('console',lambda m: mconsole.append(m.text) if m.type=='error' else None)
    mob.goto(URI); mob.wait_for_timeout(250); check_overflow(mob,'home mobile 390'); mob.screenshot(path=str(ROOT/'qa'/'homepage-mobile.png'),full_page=False)
    assert_true(mob.locator('.logo-mark').is_visible(),'mobile canonical logo mark not visible')
    # 320
    tiny=browser.new_page(viewport={"width":320,"height":780}); tiny.goto(URI); tiny.wait_for_timeout(150); check_overflow(tiny,'home mobile 320')
    if mconsole: errors.extend([f'mobile console: {x}' for x in mconsole])
    browser.close()
report={'results':results,'errors':errors}
(ROOT/'qa'/'BROWSER_QA.json').write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8')
md=['# Bellentry Homepage Architecture 1.0 — Browser QA','']+[f'- {x}' for x in results]+['',f'Errors: {len(errors)}']
if errors: md+=['']+[f'- {x}' for x in errors]
else: md+=['','PASS — hero search, filters, property navigation, gallery, save/My Bellentry, Property Check, contact preview, menu, cinematic scroll and responsive overflow checks all passed in isolated Chromium.']
(ROOT/'qa'/'BROWSER_QA.md').write_text('\n'.join(md),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False))
raise SystemExit(1 if errors else 0)
