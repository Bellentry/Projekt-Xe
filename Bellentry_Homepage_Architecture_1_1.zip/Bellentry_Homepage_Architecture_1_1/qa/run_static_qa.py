from pathlib import Path
from bs4 import BeautifulSoup
from urllib.parse import urlsplit
import re,json
ROOT=Path(__file__).resolve().parents[1]
errors=[]; warnings=[]; link_count=0; button_count=0
htmls=sorted(ROOT.glob('*.html'))
for f in htmls:
    soup=BeautifulSoup(f.read_text(encoding='utf-8'),'html.parser')
    ids=[x.get('id') for x in soup.find_all(id=True)]
    if len(ids)!=len(set(ids)): errors.append(f'{f.name}: duplicate ids')
    for a in soup.find_all('a',href=True):
        link_count+=1; href=a['href']
        if href.startswith(('http://','https://','mailto:','tel:')): continue
        u=urlsplit(href); path=u.path
        if path:
            target=(f.parent/path).resolve()
            if not target.exists(): errors.append(f'{f.name}: missing link target {href}')
        if u.fragment:
            target_file=(f.parent/path).resolve() if path else f
            if target_file.exists() and target_file.suffix=='.html':
                ts=BeautifulSoup(target_file.read_text(encoding='utf-8'),'html.parser')
                if not ts.find(id=u.fragment): errors.append(f'{f.name}: missing fragment #{u.fragment} in {target_file.name}')
    for img in soup.find_all('img',src=True):
        src=img['src']
        if src.startswith('data:'): continue
        target=(f.parent/urlsplit(src).path).resolve()
        if not target.exists(): errors.append(f'{f.name}: missing image {src}')
        if img.get('alt') is None: errors.append(f'{f.name}: img missing alt')
    for b in soup.find_all('button'):
        button_count+=1
        if not b.get('type'): errors.append(f'{f.name}: button without type')
        classes=set(b.get('class') or [])
        has_hook=bool(b.get('data-save') or b.get('data-gallery-thumb') or b.get('data-check-next') is not None or b.get('data-check-back') is not None or b.get('data-clear-filters') is not None or 'menu-toggle' in classes or b.get('type')=='submit')
        if not has_hook: warnings.append(f'{f.name}: button purpose not recognized: {b.get_text(" ",strip=True)[:40]}')
# Explicit public landing regression rules
idx=(ROOT/'index.html').read_text(encoding='utf-8')
for token in ['01 /','02 /','03 /','04 /','hero-index','cinema-index']:
    if token in idx: errors.append(f'index.html: public chapter/index artifact remains: {token}')
for required in ['Immobilien finden.','Eigentum weiterbringen.','data-search-form','eigentum.html','immobilien.html','data-cinematic','Property Passport','Bellentry Verified','Mein Bellentry']:
    if required not in idx: errors.append(f'index.html missing required architecture element: {required}')
# logo lock
for f in htmls:
    txt=f.read_text(encoding='utf-8')
    if 'bellentry-logo-full.png' not in txt or 'bellentry-logo-mark.png' not in txt:
        errors.append(f'{f.name}: canonical logo assets missing')
report={'pages':len(htmls),'links':link_count,'buttons':button_count,'errors':errors,'warnings':warnings}
(ROOT/'qa'/'STATIC_QA.json').write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8')
md=['# Bellentry Homepage Architecture 1.0 — Static QA','',f'- Pages: {len(htmls)}',f'- Links checked: {link_count}',f'- Buttons checked: {button_count}',f'- Errors: {len(errors)}',f'- Warnings: {len(warnings)}','']
if errors: md+=['## Errors']+[f'- {x}' for x in errors]
else: md+=['## Result','PASS — no missing local targets/assets, duplicate IDs, untyped buttons or public chapter-number artifacts found.']
if warnings: md+=['','## Warnings']+[f'- {x}' for x in warnings]
(ROOT/'qa'/'STATIC_QA.md').write_text('\n'.join(md),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False))
raise SystemExit(1 if errors else 0)
