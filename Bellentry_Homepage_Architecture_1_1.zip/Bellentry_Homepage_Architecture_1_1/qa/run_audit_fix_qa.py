from pathlib import Path
from playwright.sync_api import sync_playwright
from bs4 import BeautifulSoup
import json
R=Path(__file__).resolve().parents[1]
js=(R/'assets/js/site.js').read_text()
css=(R/'assets/css/site.css').read_text()
def load(page,name):
    html=(R/name).read_text(); soup=BeautifulSoup(html,'html.parser')
    for x in soup.select('script[src],link[rel=stylesheet]'): x.decompose()
    soup.head.append(BeautifulSoup(f'<style>{css}</style>','html.parser'))
    soup.body.append(BeautifulSoup(f'<script>{js}</script>','html.parser'))
    page.set_content(str(soup),wait_until='load')
results={}
with sync_playwright() as p:
    b=p.chromium.launch(headless=True); page=b.new_page(viewport={'width':1440,'height':900})
    load(page,'property-check.html')
    branch=[]
    for goal in ['vermieten','verkaufen','verwalten','sanieren']:
        page.reload() if False else None
        load(page,'property-check.html'); page.check(f'input[name=goal][value={goal}]'); page.click('[data-check-next]'); branch.append(not page.locator('[data-step="1"]').is_hidden())
    results['property_check_all_goals']=all(branch)
    load(page,'property-check.html'); page.check('input[name=goal][value=verkaufen]'); page.click('[data-check-next]')
    kinds=[]
    for kind in ['wohnung','haus','mehrfamilienhaus','sonstiges']:
        load(page,'property-check.html'); page.check('input[name=goal][value=verkaufen]'); page.click('[data-check-next]'); page.check(f'input[name=kind][value={kind}]'); page.click('[data-check-next]'); kinds.append(not page.locator('[data-step="2"]').is_hidden())
    results['property_check_all_kinds']=all(kinds)
    load(page,'index.html'); page.click('.menu-toggle'); f=[]
    for _ in range(20): page.keyboard.press('Tab'); f.append(page.evaluate('document.activeElement.closest("#menu")!==null'))
    results['menu_focus_trapped']=all(f)
    load(page,'beratung.html'); page.evaluate("history.replaceState({},'', '?objekt=gross-flottbek')"); page.reload() if False else None
    # re-run JS after URL update by reloading content not possible, invoke event by reset content with base URL unsupported; direct query test via init URL context
    page2=b.new_page(); html=(R/'beratung.html').read_text(); soup=BeautifulSoup(html,'html.parser');
    for x in soup.select('script[src],link[rel=stylesheet]'): x.decompose()
    soup.body.append(BeautifulSoup(f'<script>{js}</script>','html.parser'))
    page2.goto('about:blank?objekt=gross-flottbek'); page2.set_content(str(soup));
    results['consultation_identity_fields']=page2.locator('input[name=name]').count()==1 and page2.locator('input[name=email]').count()==1
    load(page,'property-gross-flottbek.html'); page.click('[data-space="schlafen"]'); results['spatial_switch']= 'Schlafen' in page.locator('[data-space-detail]').inner_text()
    results['gallery_active']=page.locator('[data-gallery-thumb][aria-pressed=true]').count()==1
    b.close()
print(json.dumps(results,ensure_ascii=False,indent=2))
assert all(results.values()), results
