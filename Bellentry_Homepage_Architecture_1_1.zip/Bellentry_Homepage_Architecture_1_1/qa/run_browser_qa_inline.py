from pathlib import Path
from playwright.sync_api import sync_playwright
from bs4 import BeautifulSoup
import base64, mimetypes, json
ROOT=Path(__file__).resolve().parents[1]
CSS=(ROOT/'assets/css/site.css').read_text(encoding='utf-8')
JS=(ROOT/'assets/js/site.js').read_text(encoding='utf-8')

def data_uri(path:Path):
    mime=mimetypes.guess_type(path.name)[0] or 'application/octet-stream'
    return f'data:{mime};base64,'+base64.b64encode(path.read_bytes()).decode()

def inline_page(name):
    path=ROOT/name
    soup=BeautifulSoup(path.read_text(encoding='utf-8'),'html.parser')
    for link in soup.find_all('link',rel='stylesheet'):
        st=soup.new_tag('style'); st.string=CSS; link.replace_with(st)
    for sc in soup.find_all('script',src=True):
        sc2=soup.new_tag('script'); sc2.string=JS; sc.replace_with(sc2)
    for img in soup.find_all('img',src=True):
        src=img['src']
        if not src.startswith(('data:','http:','https:')):
            p=(path.parent/src).resolve()
            if p.exists(): img['src']=data_uri(p)
    return str(soup)

results=[]; errors=[]
def ok(cond,msg):
    if not cond: errors.append(msg)
def overflow(page,label):
    v=page.evaluate('document.documentElement.scrollWidth-document.documentElement.clientWidth')
    results.append(f'{label}: overflow {v}px')
    if v>1: errors.append(f'{label}: horizontal overflow {v}px')

with sync_playwright() as p:
    browser=p.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':1440,'height':1000})
    console=[]; page.on('console',lambda m: console.append(m.text) if m.type=='error' else None)
    page.set_content(inline_page('index.html'),wait_until='load'); page.wait_for_timeout(180)
    overflow(page,'homepage desktop')
    ok(page.locator('.hero-search').is_visible(),'homepage search not visible')
    ok(page.locator('.path-split').is_visible(),'two primary paths not visible')
    ok(page.locator('.property-grid').count()>=1,'featured properties missing')
    ok(page.locator('[data-cinematic]').count()==1,'cinematic module missing')
    # no public chapter labels/numbers
    txt=page.locator('body').inner_text()
    for bad in ['01 / RAUM','02 / STRUKTUR','03 / EVIDENZ','04 / NÄCHSTER SCHRITT']:
        ok(bad not in txt,f'legacy chapter label visible: {bad}')
    page.screenshot(path=str(ROOT/'qa'/'homepage-desktop.png'),full_page=False)
    # menu
    page.locator('.menu-toggle').click(); ok(page.locator('#menu').is_visible(),'menu did not open'); page.keyboard.press('Escape'); ok(not page.locator('#menu').is_visible(),'menu did not close')
    # cinema scroll progress later in page
    page.locator('[data-cinematic]').scroll_into_view_if_needed(); page.evaluate('window.scrollBy(0, innerHeight*1.4)'); page.wait_for_timeout(100)
    c=float(page.locator('.cinematic-sticky').evaluate("e=>parseFloat(getComputedStyle(e).getPropertyValue('--cinema'))||0")); ok(c>0.05,'cinematic progress did not update')
    # search filter
    page.set_content(inline_page('immobilien.html'),wait_until='load'); page.wait_for_timeout(100)
    overflow(page,'search desktop')
    ok(page.locator('[data-result-count]').inner_text()=='3','search initial count not 3')
    page.locator('select[name="zugang"]').select_option('wbs'); page.locator('[data-filter-form] button[type="submit"]').click(); page.wait_for_timeout(60)
    ok(page.locator('[data-result-count]').inner_text()=='1','WBS filter should return 1')
    ok(page.locator('[data-property]:not([hidden])').count()==1,'WBS filter visible card mismatch')
    # gallery & save
    page.set_content(inline_page('property-gross-flottbek.html'),wait_until='load'); page.wait_for_timeout(80)
    main=page.locator('[data-gallery-main]'); before=main.get_attribute('src')
    page.locator('[data-gallery-thumb]').nth(1).click(); after=main.get_attribute('src'); ok(before!=after,'gallery button did not change image')
    save=page.locator('[data-save]').first; save.click(); ok(save.inner_text().strip().lower()=='gemerkt','save button did not toggle')
    # window.name fallback persists into next set_content
    page.set_content(inline_page('mein-bellentry.html'),wait_until='load'); page.wait_for_timeout(80)
    ok(page.locator('.saved-item').count()==1,'saved item not visible in My Bellentry fallback')
    # property check
    page.set_content(inline_page('property-check.html'),wait_until='load'); page.wait_for_timeout(60)
    page.locator('input[name="goal"][value="vermieten"]').check(); page.locator('[data-check-next]').click();
    page.locator('input[name="kind"][value="wohnung"]').check(); page.locator('[data-check-next]').click();
    page.locator('input[name="docs"][value="grundriss"]').check(); page.locator('[data-check-next]').click();
    ok(page.locator('[data-check-finish]').is_visible(),'Property Check finish CTA not visible')
    ok('vermieten' in page.locator('[data-check-result]').inner_text().lower(),'Property Check result missing selection')
    # contact form
    page.set_content(inline_page('beratung.html'),wait_until='load'); page.wait_for_timeout(60)
    page.select_option('select[name="topic"]',label='Vermieten'); page.fill('textarea[name="message"]','Testanliegen für QA'); page.check('.consent input'); page.locator('[data-preview-contact] button[type="submit"]').click();
    ok('keine Kontaktdaten' in page.locator('[data-form-status]').inner_text(),'contact preview status missing')
    # mobile
    mob=browser.new_page(viewport={'width':390,'height':844})
    mconsole=[]; mob.on('console',lambda m: mconsole.append(m.text) if m.type=='error' else None)
    mob.set_content(inline_page('index.html'),wait_until='load'); mob.wait_for_timeout(120); overflow(mob,'homepage mobile 390'); ok(mob.locator('.logo-mark').is_visible(),'mobile logo mark not visible'); mob.screenshot(path=str(ROOT/'qa'/'homepage-mobile.png'),full_page=False)
    tiny=browser.new_page(viewport={'width':320,'height':780}); tiny.set_content(inline_page('index.html'),wait_until='load'); tiny.wait_for_timeout(100); overflow(tiny,'homepage mobile 320')
    if console: errors += [f'console: {x}' for x in console]
    if mconsole: errors += [f'mobile console: {x}' for x in mconsole]
    browser.close()

report={'results':results,'errors':errors}
(ROOT/'qa'/'BROWSER_QA.json').write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8')
md=['# Bellentry Homepage Architecture 1.0 — Browser QA','']+[f'- {x}' for x in results]+['',f'- Errors: {len(errors)}','']
if errors: md+=['## Errors']+[f'- {x}' for x in errors]
else: md+=['## Result','PASS — isolated Chromium render verified menu, search filters, gallery controls, session-safe favorites fallback, My Bellentry projection, Property Check, contact-preview behavior, cinematic progress, and 1440/390/320 responsive overflow.','', 'Navigation itself is verified by the static link-target audit because this execution environment blocks local file/http navigation in Chromium.']
(ROOT/'qa'/'BROWSER_QA.md').write_text('\n'.join(md),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False))
raise SystemExit(1 if errors else 0)
