# Bellentry Homepage Architecture 1.0

Stand: 04.10.2026

This package is the first homepage-focused Bellentry build after the 0.5.x cinematic experiments. The public page is deliberately reorganized around orientation and real actions first; the cinematic Property Intelligence sequence remains, but later in the journey.

## Open the standalone preview
Open `index.html`. All public navigation in the standalone package uses relative links, so the primary links work without a web server.

## What is implemented
- Clear orientation hero with Mieten / Kaufen / Wohnen auf Zeit search entry.
- Separate `Ich suche` and `Ich besitze` paths.
- Three real preview property cards with dedicated property pages.
- Functional preview search filters with URL-state support.
- Functional image galleries.
- Session-safe/fallback property saving and My Bellentry projection.
- Property Passport / Bellentry Verified example for Groß Flottbek.
- Interactive Property Check.
- Expanded owner journeys: sell, let, manage.
- Expanded services: build/renovate, finance, invest, temporary living.
- Knowledge and consultation surfaces.
- Cinematic Property Intelligence module moved below the core orientation content and stripped of public chapter counters.

## Preserved work
`server_core/` contains the existing 0.5.2 FastAPI / SQLAlchemy / Alembic vertical-slice backend and tests so the homepage redesign does not erase the domain-engineering work.

## Truthful limitations
The standalone public preview is not a deployed production application. It does not send consultation forms to a live backend and does not claim that it does. Search currently operates over the three preview properties. The preserved server core contains the real database-backed Groß-Flottbek inquiry/domain proof, but the 20-page standalone export is not yet fully wired to it.

See `qa/STATIC_QA.md`, `qa/BROWSER_QA.md`, `docs/ACTION_CONTRACTS_1_0.md` and `docs/STRICT_REVIEW_1_0.md`.
